from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Python Search Tools',
    author='jith',
    author_email='jith@test.com',
    url='testdomain.com',
    py_modules=['vsearch'],
)
